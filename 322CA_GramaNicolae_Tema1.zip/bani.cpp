// Copyright Grama Nicolae 2020
#include <algorithm>
#include <fstream>
#include <vector>

using namespace std;

fstream in("bani.in");
ofstream out("bani.out");

#define lint long int

int main() {
    lint n;
    in >> n;

    // solve(arr);

    in.close();
    out.close();
    return 0;
}
